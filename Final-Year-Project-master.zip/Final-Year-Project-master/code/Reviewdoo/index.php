 
<?php 
    // Silence is golden
