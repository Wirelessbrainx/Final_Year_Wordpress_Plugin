---
author: Oliver Grimes
---
# What Students Are Looking For:
1. University and Course Entry Requiments
2. Type of University - Clustered into groups Aka Russel Group, University Alliance
3. Location of the university
4. Student Satisfaction scores
  look into this. IS it based on an aggregate? Find the data
5. Course content / Structure !important as it differes from each university
  What units the courses have
6. Course Content
7. How you will be assessed
  Coursework vs exams
8. Graduation Prospects
9. Accreditation
10. How many people recieved offers for the course the previous year.
11. Open day's, Days for viewing the university
12. Accomidation
13. Campus parking / public Travel - Ease
14. Journey to and from home
15. Student population Satistics aka how many Female and males. Culture background
16. Rankings
17. Average Graduate salary for the course
18. Campus information
19. University Culture
20. Cost of Transport / QOL
21. Societies avalible
22. Close shops
23. Night life
24. Student welfare
25. Disablitliy help / support.
26. Drop out rate

Which? surveyed prospective students last year and found that the most important topics they want to know about are course content (77%), academic reputation (57%), distance from home (57%) and quality of academic facilities (57%).


