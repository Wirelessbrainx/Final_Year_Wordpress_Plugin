# Final-Year-Project

For Friday 2nd Feb


 ## Ollie
	- Write user testing document
		- Requirement
			- Please create a word document that details how we can perform user testing of prototypes.
			- This should be suitable to go in the corpus
			- Must consider these key areas
				- How the prototypes can be created
					- Balsamiq or another tool to create functional prototypes?
					- Paper print-outs?
				- How the prototypes can be tested
					- Remotely?
					- In person?
				- Who will test them
					- What demographics they represent
						- Friends and family?
						- We want both visitors and admins
				- What we might find from the testing and what we will do with that information
		- Info
			- need to find the best way to achieve results
			- We want to find results and use them to improve products
			- design what we want to know from the user testing
				- then design a test to find this out
			- cover a range of demographics
				- need to ask preliminary questions to find out what type of user they represent
				- design a questionaire
			- Try to cover all areas to avoid the elephant in the room
				- eg shipping a product without an off button
	- Continue with wordpress framework plugin
	
## Aaron
	- Finish mockup designs ready for prototyping round
	- Write architecture document if time permits
