# Synopsis
Taxonomy based web-application for public review of Educational Institutions.
 
## Group Size
Individual Project (1)
2
 
# The issue
University review websites in the UK offer the public very little in the way of rating their experiences. Whatuni.com restricts users to a limited 0-5* review of 9 areas, which are then commented upon to provide information. These comments usually contain key data that users are interested in. However, the review framework used is too limited to allow these areas to themselves be ranked and offers little in the way of suggesting other areas of interest to be investigated. This has a detrimental effect on the website's ability to search for and compare education institutions as it is not able to perform a comparison based upon important data hidden in user comments.
 
Websites that utilise this limited type of comment-based review system exhibit the following issues:
 
Invalid data: "I don't know X but...."
This problem is common on websites that use comments for their reviews. Users are forced into rating an issue that they don't have any knowledge of, resulting in data of questionable validity.
 
Redundant data: "One time my grandma picked me up and....."
Another prevalent issue is where <10% the content of a review is relevant and/or useful information. People have a tendency to ramble when they are presented with a broad and open-ended question.
 
Insufficient data: "I think X was OK."
This situation arises when a user leaves a rating yet fails to provide an explanation for why they reached that conclusion.
 
Contradictory data: "I loved X, but..." < user rated X 1/5* >
This issue occurs when a user either rates something low and then infers high overall satisfaction in their comment, or visa versa. The cause of this is the inability to see the individual weightings the user chose that caused the overall ranking to be so low.
 
This project intends to create a system to resolve these problems, whilst still being accessible and engaging for users.

# Overview

I propose that a new system is developed that will allow users to rate their experiences from a taxonomical pool many times larger than the status quo. A relevance, search and filtering algorithm will need developing, along with an interface and data structure that is out of the ordinary.

Dynamic creation of a folksonomy will be outside the scope of this project. In its place, research can be undertaken to investigate the areas that the public consider metrics to rate Education Institutions. A dataset will be created with information about Institutions in the UK and their corresponding taxonomical tags. Depending on the scope of the project, users will be invited to rate these tags for their institutions, otherwise, dummy data will be created.
 
The web application must facilitate search and exploration of a nested taxonomy designed in a way that the taxonomic tags (eg accessibility) and how they are categorised, ranked and rated are the key pieces of information used to describe an Institution, rather than lengthy textual comments.
 
A variety of cutting-edge technologies will be utilised to achieve this goal. Data and secure functions will be stored in the cloud and the UI will be developed as a modern single-page-application using javascript. Research may be conducted to investigate methods of achieving an acceptable level of search-engine indexability when utilising these technologies. This is a current area of confusion in the javascript world and a general requirement of a successful web project.
 
# Proposed Technologies
Database, search index and back-end functions to be stored in the cloud (Google Firebase, Google Cloud Functions, ElasticSearch)
Use of a Javascript framework (React, Angular or Vue.js)
Use of a CSS framework (Undecided)

# The Data Model
The database will be comprised of semantic tags, tag categories and Institutions. A JSON Tree structure will be utilised to store and nest the data.
 
Semantic tags (eg accessibility, resources, quality of teaching) are the smallest element in the dataset, they represent a specific area of an Institution. Semantic tags are stored against Institutions. Semantic tags are responsible for storing two types of data: relevance and score. Relevance will represent the average weighting that the community has given this tag in relation to all other tags stored against the Institution. A high relevance will make a tag have higher visual priority over other tags. Score will represent the average score the community has decided this taxonomic area should have for the Institute in question.
 
Semantic Tags may be aliased by a phrase or word depending on the score the community has given to the Institution. For example, 'Safety' with a score of 8/10 may be aliased by 'Safe', whereas if it had a low score it may be aliased by 'Unsafe'. This will be further explained in the search section.

Semantic tags can be nested within other semantic tags (eg accessibility > wheelchair), this will allow an overall score to be stored against the parent semantic tag (based upon the weighting of it's children) whilst also having an individual score for the child tags.

Tag categories (eg Schools) represent a more broad taxonomic area that will be used to categorise and order semantic tags. Like semantic tags, these can be nested within other tags of the same type (eg Schools > University).  A tag category may have many other tag categories and their corresponding semantic tags stored against it.

Finally, Institutions (eg Kent University) will represent an instance of a tag category. Institutions will be of great importance in the web-application as they tie everything together.

# Search Component - important
Users will be able to invoke the tag searcher to query Institutions and the taxonomy stored against them. When a user inputs text, the Tag Renderer component will be fired, presenting options to the user and allowing them to select a match, in addition to Autocomplete suggestions.
 
This may be represented as a search bar that users type into. As an example, if a user searched for "Safe Colleges", the system would return a graphical display of all Institutions with the Tag Category of "Colleges" that have the Semantic Tag "Safety" of 8/10 or above.
 
The "Colleges" element in the search bar will represent its Tag Category and can be clicked, expanding the Tag Renderer.
 
A custom parsing algorithm will need creating to allow user input to restrict search results. For example, the word "in" may be an alias for the "Location" Tag Category that initiates an event to narrow search results that the Tag Renderer (and autocomplete) will display to users.
 
Users will be able to interact with the Search Component and the Tag Renderer to continually manipulate and restrict their search. Complicated searches may be possible such as "Universities and Colleges with >=7 safety and 1/10 accessibility by wheelchair that are located in London".
 
# Tag Renderer Component
The Tag Renderer will be invoked by the Search Component and will also be displayed on an Institutions page as a way to navigate the JSON Tree of tags (and their scores) stored against it. The Tree will be displayed in a modified format, as decided by an algorithm that takes into consideration the weightings and relevance of the Semantic Tags stored against an Institution.
 
# Voting Component (Optional depending on scope of project)
Users may be able to vote on the score and relevance of Semantic Tags throughout the system. This would include initialising tags with a score where it previously had none (eg nobody had yet given Kent Uni a rating on its wheelchair accessibility). These updates will be pushed over web sockets and immediately update the display of all users on the system. This would also open the possibility for other enhancements such as notifications when data changes.
 
# Profile Component (Optional depending on scope of project)
This would require the ability to create accounts being in the project scope. Users could create profiles with preferences (eg year of study, course, interests) that can be used to enhance the data collected and refine the data viewed.
 
# Algorithm Transparency Component (Optional depending on scope of project)
Requires the voting component to be in the project scope. It will allow the user to view how many individuals have voted on a taxonomical tag and display any relevant information about how the score was calculated. If the profile component is in the project scope, it will also allow a breakdown of what type of people have voted for what, when they voted for it, and perhaps even allow temporal traversal to display what the scores looked like at certain points in time.

# Comment Parsing Component (Optional depending on scope of project)
Requires the voting component to be in the project scope. Users will be able to leave various types of specifically focused comments for the Institution. Complaints and tips are two examples. As the user types, their text may be parsed to see if any keywords are used that relate to a Semantic Tag. If a match is found, the user may be prompted to quickly rate it.
